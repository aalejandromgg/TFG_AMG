


function pdf=stablepdf_interp(parms,x)
%pdf=stablepdf_interp(parms,x)
%
% (c) Federico Simmross-Wattenberg
%
%returns an arbitrary stable PDF evaluated at vector x, based on a
%precomputed grid previously generated with stabletabulate.m
%
%parms=[alpha beta gamma delta]
global stable_table;
global tri;
global T;
alpha=parms(1);beta=parms(2);gamma=parms(3);delta=parms(4);
absbeta=abs(beta);
%Get the triangle that encloses the requested point and its barycentric
%coordinates
[tri_idx,bar_coords]=pointLocation(T,alpha,absbeta);
if(isnan(tri_idx))
    % fprintf('stablepdf_interp: requested point is outside the grid (alpha=%1.10f, beta=%1.10f)\n',alpha,beta);
    pdf=0;
    return;
end
%get the stored points of stable PDFs at the 3 vertices of the enclosing
%triangle
nearest_idx1=tri(tri_idx,1);
nearest_idx2=tri(tri_idx,2);
nearest_idx3=tri(tri_idx,3);
xtable1=stable_table{nearest_idx1,3}(1,:);
ytable1=stable_table{nearest_idx1,3}(2,:);
xtable2=stable_table{nearest_idx2,3}(1,:);
ytable2=stable_table{nearest_idx2,3}(2,:);
xtable3=stable_table{nearest_idx3,3}(1,:);
ytable3=stable_table{nearest_idx3,3}(2,:);
%Un-normalize stored PDFs
x=x-delta;
if(beta<0)
    x=-x;
end
xtable1=xtable1*gamma;
xtable2=xtable2*gamma;
xtable3=xtable3*gamma;
%Interpolate the stored PDFs at the requested x points
pdf1=interp1(xtable1,ytable1,x,'pchip',0);
pdf2=interp1(xtable2,ytable2,x,'pchip',0);
pdf3=interp1(xtable3,ytable3,x,'pchip',0);
%Return requested PDF
pdf=(bar_coords(1)*pdf1+bar_coords(2)*pdf2+bar_coords(3)*pdf3)/gamma;
if(any(pdf<0))
    fprintf('stablepdf_inerp: some PDF values rendered below 0!\n');
end

