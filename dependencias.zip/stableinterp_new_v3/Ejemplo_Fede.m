
%/*-----------------------------------------------------------
%   Ejemplo_Fede : programa para probar la librería de Federico 
%                  Simmross-Wattenberg
%--------------------------------------------------------------*/


clear all;
addpath('./stableinterp_new_v3/');
global T;
global tri;
global stable_table;

% Numero de muestras de la distribución que se ajusta
MUESTRAS = 1e4;

% Carga de la tabla precalculada y triangulación
load stable_table_40db.mat
tri=delaunay(ab);
T=triangulation(tri,ab);
triplot(T,'-b*');

% Generación de las muestras de la distribución 
% alfa estable definida por a0, b0, c0 y d0
a0 = 1.5;
b0 = 0.8;
c0 = 235.0; 
d0 = 56759.0;
fprintf ("Number of samples : %.2e\n", MUESTRAS);
fprintf('Parameters for sampling : \n')
fprintf("a: %f\nb: %f\nc : %f\nd :%f\n", a0,b0,c0,d0)
samples=random('Stable',a0,b0,c0,d0,MUESTRAS,1);

% Normalizacion
media = mean(samples);
sigma = std (samples);
samples =(samples - media)/sigma;

fprintf ('mean: %.1f,  sigma:  %.1f \n', media, sigma);


% Ajuste inicial
parms=stablefit_init(samples);
fprintf('Initial estimation : \n')
fprintf("a: %f\nb: %f\nc : %f\nd :%f\n", parms(1),parms(2),parms(3),parms(4))
a = parms(1);
b = parms(2);
c = parms(3);
d = parms(4);



% Ajuste de las muestras y estimación de error en el ajuste 
[a,b,c,d]=stablefit(samples,parms);

fprintf('Final estimation : \n')
fprintf("a: %f\nb: %f\nc : %f\nd :%f\n", a,b,c,d)


samples1 = random('Stable',a,b,c,d,MUESTRAS,1);
[h,p] = kstest2(samples,samples1,'Alpha',0.01);
if h == 0 
  fprintf('K-S success:  h= %d,  p=%.2f with significant level of 1%%\n', h, p);
else
  fprintf('K-S test failed\n');
end
figure;
edges = -1.5:0.05:1.5;
h = histogram (samples, edges,'Normalization', 'pdf');
hold on;

stable_dist = makedist('Stable','alpha',a,'beta',b,'gam',c,'delta',d);
pdf = pdf(stable_dist, edges);
plot (edges, pdf, 'r-','LineWidth',3);
titulo = sprintf('Stable fit ( %.1f,  %.1f,  %.1f,  %.1f )',a0,b0,c0,d0);
title(titulo)
xlabel (' Normlized variable (x-mean)/std')
hold off