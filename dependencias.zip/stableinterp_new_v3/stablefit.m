function [alpha,beta,gamma,delta]=stablefit(data,init)
%[alpha,beta,gamma,delta]=stablefit(data,init)
%
% (c) Federico Simmross-Wattenberg
%
%Returns Maximum Likelihood estimates for stable parameters based on a
%precomputed grid previously generated with stabletabulate.m
%
%Parameters:
%    data: Data vector to obtain estimates from
%    init: 1x4 vector containing an initial guess for the stable parameters
%          You may use stablefit_init.m to obtain it.
global stable_table;
%Set bounds for alpha,beta from the grid
alpha_lower=stable_table{1,1};
alpha_upper=stable_table{end,1};
beta_lower=stable_table{1,2};
beta_upper=stable_table{end,2};
%Set sane bounds for gamma, delta. Adjust to your needs.
gamma_lower=1e-1; %Smaller values require grids with larger abscissa intervals.
gamma_upper=10;
delta_lower=-10;
delta_upper=10;
optimOptions=optimset('Display','off','Algorithm','sqp','ObjectiveLimit',1e-8);
parms=fmincon(@(x)log_likelihood(x,data),init,[],[],[],[],[alpha_lower beta_lower gamma_lower delta_lower],[alpha_upper beta_upper gamma_upper delta_upper],[],optimOptions);
alpha=parms(1);
beta=parms(2);
gamma=parms(3);
delta=parms(4);
end
function lh=log_likelihood(parms,data)
    pdf = stablepdf_interp(parms,data);
    if pdf == 0
        lh = 1e10;
    else
        log_pdf=log(pdf);
        lh=-sum(log_pdf(isfinite(log_pdf)));
    end
    % fprintf("a: %f, b: %f, c : %f, d :%f, lh : %f\n", parms(1),parms(2),parms(3),parms(4), lh)
end

