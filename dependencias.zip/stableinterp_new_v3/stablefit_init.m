function parms=stablefit_init(data)
%parms=stablefit_init(data)
%
% (c) Federico Simmross-Wattenberg
%
%Returns a quick initial guess for stable parameters
%
%[1] E. E. Kuruoglu, "Density Parameter Estimation of Skewed alpha-Stable
%Distributions", IEEE Tran. Signal Processing, Vol. 49, No. 10, 2001.
%Estimate alpha as in [1], eq. (27)
L2=mean( (log(abs(data)) - mean(log(abs(data)))).^2);
if(~isnan(L2))
    psi1=pi^2/6;
    alpha=abs((L2/psi1 -0.5)^(-0.5));
    if(alpha>2)
        alpha=2;
    elseif(alpha<0.3)   %Adjust to your needs
        alpha=0.3;
    end
else
    alpha=2;
end
parms(1)=alpha;
%Estimate the mode
%1. Remove outliers
c1=prctile(data,25);
c2=prctile(data,75);
bound_min=c1-1.5*(c2-c1);
bound_max=c2+1.5*(c2-c1);
data_wo=data(data>=bound_min & data<=bound_max);
if(isempty(data_wo))
    data_wo=data;
end
%2. Calculate reasonable bins
[~,p]=hist(data_wo,fix(sqrt(length(data))));
[~,bin]=histc(data,p);
%3. Estimate the mode from the bins
m=p(mode(bin(bin~=0)));
%Estimate beta by the proportion of data above/below the mode
balance=(length(data(data>m))-length(data(data<=m)))/length(data);
parms(2)=sign(balance)*abs(balance)^(0.5);
%Estimate gamma by the std. deviation of the data without outliers
parms(3)=std(data_wo);
%Estimate delta by the mode
parms(4)=m;
end
