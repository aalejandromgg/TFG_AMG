
%/*-----------------------------------------------------------
%   Ejemplo_Fede : programa para probar la librería de Federico 
%                  Simmross-Wattenberg
%--------------------------------------------------------------*/


clear all;
addpath('./stableinterp_new_v3/');
global T;
global tri;
global stable_table;


fichero = "./TimeSeriesData/may_week3_csv/BPSyPPS.txt";
data = readtable(fichero);
% Extrae las columnas de interés
tiempo = data{:, 1}; % Tiempo en UNIX
%ELEGIR OPCION: bits por segundo o numero de paquetes por segundo
bits = data{:, 2}; % Número de bits/s
paquetes = data{:, 3}; % Número de paquetes/s

ventana = 15;
size_ventana = ventana * 60;


tiempo_comienzo = 1462771119 +1;
indice_comienzo = find(tiempo == tiempo_comienzo);


samples = paquetes(indice_comienzo:indice_comienzo +900 -1);
% Carga de la tabla precalculada y triangulación
load stable_table_40db.mat
tri=delaunay(ab);
T=triangulation(tri,ab);
triplot(T,'-b*');

% Numero de muestras de la distribución que se ajusta
MUESTRAS = 1e4;

% Normalizacion
media = mean(samples);
sigma = std (samples);
samples =(samples - media)/sigma;

fprintf ('mean: %.1f,  sigma:  %.1f \n', media, sigma);


% Ajuste inicial
parms=stablefit_init(samples);
fprintf('Initial estimation : \n')
fprintf("a: %f\nb: %f\nc : %f\nd :%f\n", parms(1),parms(2),parms(3),parms(4))
a = parms(1);
b = parms(2);
c = parms(3);
d = parms(4);



% Ajuste de las muestras y estimación de error en el ajuste 
[a,b,c,d]=stablefit(samples,parms);
fprintf('Final estimation : \n')
fprintf("a: %f\nb: %f\nc : %f\nd :%f\n", a,b,c,d)


samples1 = random('Stable',a,b,c,d,MUESTRAS,1);
[h,p] = kstest2(samples,samples1,'Alpha',0.01);
if h == 0 
  fprintf('K-S success:  h= %d,  p=%.2f with significant level of 1%%\n', h, p);
else
  fprintf('K-S test failed\n');
end
figure;
edges = -1.5:0.05:1.5;
h = histogram (samples, edges,'Normalization', 'pdf');
hold on;

stable_dist = makedist('Stable','alpha',a,'beta',b,'gam',c,'delta',d);
pdf = pdf(stable_dist, edges);
plot (edges, pdf, 'r-','LineWidth',3);

xlabel (' Normlized variable (x-mean)/std')
hold off